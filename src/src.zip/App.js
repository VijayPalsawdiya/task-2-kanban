import './App.css';
import ModalCompo from './component/ModalCompo';
import Test from './component/Test';


function App() {
  return (
    <div className="App">
      <ModalCompo />
      {/* <Test /> */}
          </div>
  );
}

export default App;
